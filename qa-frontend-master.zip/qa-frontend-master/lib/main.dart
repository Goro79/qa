import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:qaforum/constants.dart';
import 'dart:convert';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/register_screen.dart';
import 'screens/question_screen.dart';
import 'screens/create_question_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_strategy/url_strategy.dart';

void main() {
  setPathUrlStrategy();
  runApp(
    MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => AuthProvider())],
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Q&A Forum',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.grey[100],
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
      ),
      // Use home to handle initial loading and authentication check
      home: FutureBuilder(
        future:
            Provider.of<AuthProvider>(context, listen: false)._loadAuthData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          final auth = Provider.of<AuthProvider>(context, listen: false);
          return auth.isAuthenticated ? HomeScreen() : LoginScreen();
        },
      ),
      onGenerateRoute: (settings) {
        final auth = Provider.of<AuthProvider>(context, listen: false);
        final isAuthenticated = auth.isAuthenticated;

        // Public routes that don't require authentication
        if (settings.name == '/login') {
          return MaterialPageRoute(builder: (_) => LoginScreen());
        }
        if (settings.name == '/register') {
          return MaterialPageRoute(builder: (_) => RegisterScreen());
        }

        // Redirect to login if not authenticated for protected routes
        if (!isAuthenticated) {
          return MaterialPageRoute(
            builder: (_) => LoginScreen(),
            settings: RouteSettings(name: '/login'),
          );
        }

        // Handle question route with ID
        if (settings.name?.startsWith('/question/') ?? false) {
          return MaterialPageRoute(
            builder: (_) => QuestionScreen(),
            settings: settings,
          );
        }

        // Handle other protected routes
        switch (settings.name) {
          case '/home':
            return MaterialPageRoute(builder: (_) => HomeScreen());
          case '/create_question':
            return MaterialPageRoute(builder: (_) => CreateQuestionScreen());
          default:
            // Default to home for authenticated users
            return MaterialPageRoute(builder: (_) => HomeScreen());
        }
      },
    );
  }
}

class AuthProvider with ChangeNotifier {
  String? _token;
  String? _role;
  String? _username;
  int? _userId;

  AuthProvider() {
    _loadAuthData();
  }

  bool get isAuthenticated => _token != null;

  String? get token => _token;

  String? get role => _role;

  bool get isModeratorOrAdmin =>
      _role == 'moderator' || _role == 'administrator';

  bool get isAdmin => _role == 'administrator';

  String? get username => _username;

  int? get userId => _userId;

  Future<void> _loadAuthData() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('auth_token');
    _role = prefs.getString('role');
    _username = prefs.getString('username');
    _userId = prefs.getInt('user_id');
    if (_token != null) {
      notifyListeners();
    }
  }

  Future<void> _saveAuthData() async {
    final prefs = await SharedPreferences.getInstance();
    if (_token != null) {
      await prefs.setString('auth_token', _token!);
      await prefs.setString('role', _role ?? '');
      await prefs.setString('username', _username ?? '');
      await prefs.setInt('user_id', _userId ?? 0);
    }
  }

  Future<void> login(String username, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$apiUrl/api/login/'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'username': username, 'password': password}),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        _token = data['token'];
        _role = data['role'];
        _username = data['username'];
        _userId = data['user_id'];
        await _saveAuthData();
        notifyListeners();
      } else {
        final error = json.decode(response.body);
        throw Exception(error['non_field_errors']?.join(' ') ?? 'Login failed');
      }
    } catch (e) {
      throw Exception('Failed to login: ${e.toString()}');
    }
  }

  Future<void> register(String username, String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$apiUrl/api/register/'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'username': username,
          'email': email,
          'password': password,
        }),
      );
      if (response.statusCode == 201) {
        final data = json.decode(response.body);
        _token = data['token'];
        _role = data['role'];
        _username = data['username'];
        _userId = data['user_id'];
        await _saveAuthData();
        notifyListeners();
      } else {
        final error = json.decode(response.body);
        throw Exception(error['error'] ?? 'Registration failed');
      }
    } catch (e) {
      throw Exception('Failed to register: ${e.toString()}');
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('role');
    await prefs.remove('username');
    await prefs.remove('user_id');
    _token = null;
    _role = null;
    _username = null;
    _userId = null;
    notifyListeners();
  }
}
