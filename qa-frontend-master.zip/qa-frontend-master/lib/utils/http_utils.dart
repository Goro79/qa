import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:qaforum/main.dart';

class HttpUtils {
  static Future<http.Response> get(
    BuildContext context,
    String url, {
    Map<String, String>? headers,
  }) async {
    final auth = Provider.of<AuthProvider>(context, listen: false);
    final response = await http.get(
      Uri.parse(url),
      headers: {
        ...?headers,
        if (auth.token != null) 'Authorization': 'Token ${auth.token}',
      },
    );
    if (response.statusCode == 401) {
      await _handleUnauthorized(context);
    }
    return response;
  }

  static Future<http.Response> post(
    BuildContext context,
    String url, {
    Map<String, String>? headers,
    Object? body,
  }) async {
    final auth = Provider.of<AuthProvider>(context, listen: false);
    final response = await http.post(
      Uri.parse(url),
      headers: {
        ...?headers,
        if (auth.token != null) 'Authorization': 'Token ${auth.token}',
        'Content-Type': 'application/json',
      },
      body: body,
    );
    if (response.statusCode == 401) {
      await _handleUnauthorized(context);
    }
    return response;
  }

  static Future<void> _handleUnauthorized(BuildContext context) async {
    final auth = Provider.of<AuthProvider>(context, listen: false);
    await auth.logout();
    if (Navigator.canPop(context)) {
      Navigator.pushReplacementNamed(context, '/login');
    }
  }
}
