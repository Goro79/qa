import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qaforum/constants.dart';
import 'package:qaforum/main.dart';
import 'package:qaforum/models/tag.dart';
import 'package:qaforum/models/question.dart';
import 'package:qaforum/utils/http_utils.dart';
import 'dart:convert';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _HomeScreenState();
  }
}

class _HomeScreenState extends State<HomeScreen> {
  List<Question> questions = [];
  List<String> selectedTags = [];
  List<Tag> tags = [];
  bool isLoading = false;
  String? errorMessage;
  int page = 1;
  bool hasMore = true;
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    final auth = Provider.of<AuthProvider>(context, listen: false);
    if (!auth.isAuthenticated) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(context, '/login');
      });
      return;
    }
    fetchTags();
    fetchQuestions();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
              _scrollController.position.maxScrollExtent &&
          !isLoading &&
          hasMore) {
        fetchQuestions();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> fetchTags() async {
    try {
      final response = await HttpUtils.get(context, '$apiUrl/api/tags/');
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          tags =
              (data['results'] as List)
                  .map((tag) => Tag.fromJson(tag))
                  .toList();
        });
      } else {
        setState(() => errorMessage = 'Failed to load tags');
      }
    } catch (e) {
      setState(() => errorMessage = 'Error: ${e.toString()}');
    }
  }

  Future<void> fetchQuestions({bool reset = false}) async {
    if (isLoading || (!hasMore && !reset)) return;
    setState(() {
      isLoading = true;
      if (reset) {
        questions.clear();
        page = 1;
        hasMore = true;
      }
    });
    try {
      final url =
          selectedTags.isEmpty
              ? '$apiUrl/api/questions/?page=$page'
              : '$apiUrl/api/questions/?tags=${selectedTags.join(',')}&page=$page';
      final response = await HttpUtils.get(context, url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          questions.addAll(
            (data['results'] as List)
                .map((question) => Question.fromJson(question))
                .toList(),
          );
          hasMore = data['next'] != null;
          page++;
          isLoading = false;
        });
      } else {
        setState(() {
          errorMessage = 'Failed to load questions: ${response.statusCode}';
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = 'Error: ${e.toString()}';
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Q&A Forum'),
        actions: [
          if (auth.isModeratorOrAdmin)
            IconButton(
              icon: Icon(Icons.badge),
              onPressed: () {
                // Navigate to badge assignment screen (to be implemented)
              },
            ),
          if (auth.isAdmin)
            IconButton(
              icon: Icon(Icons.block),
              onPressed: () {
                // Navigate to user block screen (to be implemented)
              },
            ),
        ],
      ),
      body: Row(
        children: [
          Container(
            width: 250,
            color: Colors.white,
            child: Column(
              children: [
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Filter by Tags',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                Expanded(
                  child:
                      tags.isEmpty && errorMessage == null
                          ? Center(child: CircularProgressIndicator())
                          : ListView.builder(
                            itemCount: tags.length,
                            itemBuilder:
                                (context, index) => CheckboxListTile(
                                  title: Text(tags[index].tagName),
                                  value: selectedTags.contains(
                                    tags[index].tagName,
                                  ),
                                  onChanged: (val) {
                                    setState(() {
                                      if (val!) {
                                        selectedTags.add(tags[index].tagName);
                                      } else {
                                        selectedTags.remove(
                                          tags[index].tagName,
                                        );
                                      }
                                    });
                                  },
                                ),
                          ),
                ),
                Padding(
                  padding: EdgeInsets.all(16),
                  child: ElevatedButton(
                    onPressed: () => fetchQuestions(reset: true),
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 48),
                    ),
                    child: Text('Apply Filters'),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 3,
            child:
                questions.isEmpty && !isLoading && errorMessage == null
                    ? Center(child: CircularProgressIndicator())
                    : errorMessage != null
                    ? Center(child: Text(errorMessage!))
                    : ListView.builder(
                      controller: _scrollController,
                      padding: EdgeInsets.all(16),
                      itemCount: questions.length + (isLoading ? 1 : 0),
                      itemBuilder: (context, index) {
                        if (index == questions.length) {
                          return Center(child: CircularProgressIndicator());
                        }
                        final question = questions[index];
                        return Card(
                          margin: EdgeInsets.only(bottom: 16),
                          child: ListTile(
                            title: Text(
                              question.title,
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: Text(
                              'Category: ${question.category.name}\n'
                              'Tags: ${question.tags.map((tag) => tag.tagName).join(', ')}\n'
                              'Answers: ${question.answerCount} | Votes: ${question.voteCount} | By: ${question.user}',
                            ),
                            onTap: () {
                              Navigator.pushNamed(
                                context,
                                '/question/${question.id}',
                                arguments: question,
                              );
                            },
                          ),
                        );
                      },
                    ),
          ),
          Container(
            width: 250,
            color: Colors.white,
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'User Profile',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                SizedBox(height: 16),
                FutureBuilder(
                  future: HttpUtils.get(context, '$apiUrl/api/current_user/'),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return Text('Error loading user data');
                    }
                    if (snapshot.hasData) {
                      final user = json.decode(snapshot.data!.body);
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Username: ${user['username']}',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 8),
                          Text('Role: ${user['role']}'),
                          SizedBox(height: 8),
                          Text('Badges: ${user['badges'].join(', ')}'),
                          SizedBox(height: 8),
                          Text('Questions: ${user['question_count']}'),
                          SizedBox(height: 8),
                          Text('Answers: ${user['answer_count']}'),
                        ],
                      );
                    }
                    return CircularProgressIndicator();
                  },
                ),
                Spacer(),
                ElevatedButton(
                  onPressed: () {
                    auth.logout();
                    Navigator.pushReplacementNamed(context, '/login');
                  },
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(double.infinity, 48),
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                  ),
                  child: Text('Logout'),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.pushNamed(context, '/create_question');
          if (result == true) {
            fetchQuestions(reset: true);
          }
        },
        tooltip: 'Ask a Question',
        child: Icon(Icons.add),
      ),
    );
  }
}
