import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qaforum/constants.dart';
import 'package:qaforum/main.dart';
import 'package:qaforum/models/category.dart';
import 'dart:convert';
import 'package:qaforum/models/tag.dart';
import 'package:qaforum/utils/http_utils.dart';

class CreateQuestionScreen extends StatefulWidget {
  const CreateQuestionScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _CreateQuestionScreenState();
  }
}

class _CreateQuestionScreenState extends State<CreateQuestionScreen> {
  final _titleController = TextEditingController();
  final _bodyController = TextEditingController();
  List<Category> categories = [];
  List<Tag> tags = [];
  List<String> selectedTags = [];
  Category? selectedCategory;
  bool isLoading = false;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    final auth = Provider.of<AuthProvider>(context, listen: false);
    if (!auth.isAuthenticated) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(context, '/login');
      });
      return;
    }
    fetchCategories();
    fetchTags();
  }

  Future<void> fetchCategories() async {
    try {
      final response = await HttpUtils.get(context, '$apiUrl/api/categories/');
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          categories =
              (data['results'] as List)
                  .map((category) => Category.fromJson(category))
                  .toList();
        });
      } else {
        setState(() => errorMessage = 'Failed to load categories');
      }
    } catch (e) {
      setState(() => errorMessage = 'Error: ${e.toString()}');
    }
  }

  Future<void> fetchTags() async {
    try {
      final response = await HttpUtils.get(context, '$apiUrl/api/tags/');
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          tags =
              (data['results'] as List)
                  .map((tag) => Tag.fromJson(tag))
                  .toList();
        });
      } else {
        setState(() => errorMessage = 'Failed to load tags');
      }
    } catch (e) {
      setState(() => errorMessage = 'Error: ${e.toString()}');
    }
  }

  Future<void> createQuestion() async {
    if (_titleController.text.isEmpty ||
        _bodyController.text.isEmpty ||
        selectedCategory == null) {
      setState(() => errorMessage = 'All fields are required');
      return;
    }
    setState(() {
      isLoading = true;
      errorMessage = null;
    });
    try {
      final response = await HttpUtils.post(
        context,
        '$apiUrl/api/questions/',
        body: json.encode({
          'title': _titleController.text,
          'body': _bodyController.text,
          'category': selectedCategory!.id,
          'tags': selectedTags,
        }),
      );
      if (response.statusCode == 201) {
        if (!mounted) {
          return;
        }
        // Pop with true to signal successful question creation
        Navigator.pop(context, true);
      } else {
        setState(() => errorMessage = 'Failed to create question');
      }
    } catch (e) {
      setState(() => errorMessage = 'Error: ${e.toString()}');
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Ask a Question')),
      body:
          isLoading
              ? Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      controller: _titleController,
                      decoration: InputDecoration(
                        labelText: 'Title',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      controller: _bodyController,
                      decoration: InputDecoration(
                        labelText: 'Body',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 5,
                    ),
                    SizedBox(height: 16),
                    DropdownButtonFormField<Category>(
                      decoration: InputDecoration(
                        labelText: 'Category',
                        border: OutlineInputBorder(),
                      ),
                      items:
                          categories
                              .map<DropdownMenuItem<Category>>(
                                (category) => DropdownMenuItem<Category>(
                                  value: category,
                                  child: Text(category.name),
                                ),
                              )
                              .toList(),
                      onChanged: (value) {
                        setState(() => selectedCategory = value);
                      },
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Tags',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    Wrap(
                      spacing: 8,
                      children:
                          tags.map<Widget>((tag) {
                            final isSelected = selectedTags.contains(
                              tag.tagName,
                            );
                            return FilterChip(
                              label: Text(tag.tagName),
                              selected: isSelected,
                              onSelected: (selected) {
                                setState(() {
                                  if (selected) {
                                    selectedTags.add(tag.tagName);
                                  } else {
                                    selectedTags.remove(tag.tagName);
                                  }
                                });
                              },
                            );
                          }).toList(),
                    ),
                    if (errorMessage != null) ...[
                      SizedBox(height: 16),
                      Text(errorMessage!, style: TextStyle(color: Colors.red)),
                    ],
                    SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: createQuestion,
                      style: ElevatedButton.styleFrom(
                        minimumSize: Size(double.infinity, 48),
                      ),
                      child: Text('Submit Question'),
                    ),
                  ],
                ),
              ),
    );
  }
}
