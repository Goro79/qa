import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qaforum/constants.dart';
import 'package:qaforum/main.dart';
import 'package:qaforum/models/question.dart';
import 'package:qaforum/models/answer.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:qaforum/utils/http_utils.dart';

class QuestionScreen extends StatefulWidget {
  const QuestionScreen({super.key});

  @override
  State<StatefulWidget> createState() {
    return _QuestionScreenState();
  }
}

class _QuestionScreenState extends State<QuestionScreen> {
  Question? question;
  List<Answer> answers = [];
  bool isLoading = false;
  String? errorMessage;
  final _answerController = TextEditingController();

  @override
  void initState() {
    super.initState();
    final auth = Provider.of<AuthProvider>(context, listen: false);
    if (!auth.isAuthenticated) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(context, '/login');
      });
      return;
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)!.settings.arguments;
    if (args is Question) {
      if (question == null || question!.id != args.id) {
        setState(() {
          question = args;
          answers = [];
          errorMessage = null;
        });
        fetchAnswers();
      }
    }
  }

  Future<void> fetchAnswers() async {
    if (question == null) {
      setState(() {
        errorMessage = 'No question data available';
      });
      return;
    }
    setState(() {
      isLoading = true;
      errorMessage = null;
    });
    try {
      final response = await HttpUtils.get(
        context,
        '$apiUrl/api/answers/?question_id=${question!.id}',
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['results'] != null) {
          setState(() {
            answers =
                (data['results'] as List)
                    .map((answer) => Answer.fromJson(answer))
                    .toList();
            isLoading = false;
          });
        } else {
          setState(() {
            errorMessage = 'No answers found in response';
            isLoading = false;
          });
        }
      } else {
        setState(() {
          errorMessage = 'Failed to load answers: ${response.statusCode}';
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = 'Error fetching answers: ${e.toString()}';
        isLoading = false;
      });
    }
  }

  Future<void> vote(String contentType, int contentId, int voteValue) async {
    // Store original state for rollback in case of failure
    int? originalVoteCount;
    int? originalUserVote;
    int index = -1;

    setState(() {
      if (contentType == 'question') {
        originalVoteCount = question!.voteCount;
        originalUserVote = question!.userVote;
        // Adjust vote count and user vote locally
        if (question!.userVote == voteValue) {
          // Undo vote
          question!.voteCount += voteValue == 1 ? -1 : 1;
          question!.userVote = 0;
        } else {
          // New or change vote
          question!.voteCount +=
              question!.userVote == 0
                  ? voteValue
                  : (question!.userVote == 1 ? -1 : 1) + voteValue;
          question!.userVote = voteValue;
        }
      } else {
        index = answers.indexWhere((answer) => answer.id == contentId);
        if (index != -1) {
          originalVoteCount = answers[index].voteCount;
          originalUserVote = answers[index].userVote;
          // Adjust vote count and user vote locally
          if (answers[index].userVote == voteValue) {
            // Undo vote
            answers[index].voteCount += voteValue == 1 ? -1 : 1;
            answers[index].userVote = 0;
          } else {
            // New or change vote
            answers[index].voteCount +=
                answers[index].userVote == 0
                    ? voteValue
                    : (answers[index].userVote == 1 ? -1 : 1) + voteValue;
            answers[index].userVote = voteValue;
          }
        }
      }
    });

    try {
      final response = await HttpUtils.post(
        context,
        '$apiUrl/api/votes/',
        body: json.encode({
          'content_type': contentType,
          'content_id': contentId,
          'vote': voteValue,
        }),
      );
      if (response.statusCode != 200 && response.statusCode != 201) {
        // Revert changes on failure
        setState(() {
          if (contentType == 'question') {
            question!.voteCount = originalVoteCount!;
            question!.userVote = originalUserVote!;
          } else if (index != -1) {
            answers[index].voteCount = originalVoteCount!;
            answers[index].userVote = originalUserVote!;
          }
        });
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to vote: ${response.statusCode}')),
        );
      }
    } catch (e) {
      // Revert changes on error
      setState(() {
        if (contentType == 'question') {
          question!.voteCount = originalVoteCount!;
          question!.userVote = originalUserVote!;
        } else if (index != -1) {
          answers[index].voteCount = originalVoteCount!;
          answers[index].userVote = originalUserVote!;
        }
      });
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
    }
  }

  Future<void> report(String targetType, int targetId, String reason) async {
    try {
      final response = await HttpUtils.post(
        context,
        '$apiUrl/api/reports/',
        body: json.encode({
          'target_type': targetType,
          'target_id': targetId,
          'reason': reason,
        }),
      );
      if (!mounted) return;
      if (response.statusCode == 201) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Report submitted')));
      } else {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Failed to submit report')));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
    }
  }

  Future<void> hideContent(String contentType, int contentId) async {
    try {
      final response = await HttpUtils.post(
        context,
        '$apiUrl/api/${contentType}s/$contentId/hide/',
      );
      if (response.statusCode == 200) {
        if (!mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('$contentType hidden')));
        if (contentType == 'question') {
          Navigator.pop(context);
        } else {
          fetchAnswers();
        }
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Failed to hide $contentType')));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
    }
  }

  Future<void> postAnswer() async {
    if (_answerController.text.isEmpty || question == null) return;
    try {
      final response = await HttpUtils.post(
        context,
        '$apiUrl/api/answers/?question_id=${question!.id}',
        body: json.encode({'body': _answerController.text}),
      );
      if (response.statusCode == 201) {
        _answerController.clear();
        fetchAnswers();
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Failed to post answer')));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final dateFormatter = DateFormat('yyyy-MM-dd HH:mm');
    return Scaffold(
      appBar: AppBar(
        title: Text(question != null ? question!.title : 'Question'),
      ),
      body:
          isLoading
              ? Center(child: CircularProgressIndicator())
              : errorMessage != null
              ? Center(child: Text(errorMessage!))
              : question == null
              ? Center(child: Text('No question data available'))
              : SingleChildScrollView(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              question!.title,
                              style: Theme.of(context).textTheme.titleLarge,
                            ),
                            SizedBox(height: 8),
                            Text(
                              'By: ${question!.user} | Posted: ${dateFormatter.format(question!.createdAt)}',
                              style: TextStyle(color: Colors.grey),
                            ),
                            SizedBox(height: 8),
                            Text(question!.body),
                            SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              children:
                                  question!.tags
                                      .map<Widget>(
                                        (tag) => Chip(label: Text(tag.tagName)),
                                      )
                                      .toList(),
                            ),
                            SizedBox(height: 8),
                            Row(
                              children: [
                                IconButton(
                                  icon: Icon(
                                    question!.userVote == 1
                                        ? Icons.thumb_up
                                        : Icons.thumb_up_outlined,
                                    color:
                                        question!.userVote == 1
                                            ? Colors.blue
                                            : null,
                                  ),
                                  onPressed:
                                      () => vote('question', question!.id, 1),
                                ),
                                Text('${question!.voteCount}'),
                                IconButton(
                                  icon: Icon(
                                    question!.userVote == -1
                                        ? Icons.thumb_down
                                        : Icons.thumb_down_outlined,
                                    color:
                                        question!.userVote == -1
                                            ? Colors.red
                                            : null,
                                  ),
                                  onPressed:
                                      () => vote('question', question!.id, -1),
                                ),
                                Spacer(),
                                IconButton(
                                  icon: Icon(Icons.report),
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      builder: (context) {
                                        final reasonController =
                                            TextEditingController();
                                        return AlertDialog(
                                          title: Text('Report Question'),
                                          content: TextField(
                                            controller: reasonController,
                                            decoration: InputDecoration(
                                              labelText: 'Reason',
                                            ),
                                          ),
                                          actions: [
                                            TextButton(
                                              onPressed:
                                                  () => Navigator.pop(context),
                                              child: Text('Cancel'),
                                            ),
                                            TextButton(
                                              onPressed: () {
                                                report(
                                                  'question',
                                                  question!.id,
                                                  reasonController.text,
                                                );
                                                Navigator.pop(context);
                                              },
                                              child: Text('Submit'),
                                            ),
                                          ],
                                        );
                                      },
                                    );
                                  },
                                ),
                                if (auth.isModeratorOrAdmin)
                                  IconButton(
                                    icon: Icon(Icons.visibility_off),
                                    onPressed:
                                        () => hideContent(
                                          'question',
                                          question!.id,
                                        ),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Answers (${answers.length})',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    if (answers.isEmpty)
                      Padding(
                        padding: EdgeInsets.symmetric(vertical: 16),
                        child: Text('No answers yet.'),
                      ),
                    ...answers.map(
                      (answer) => Card(
                        margin: EdgeInsets.only(top: 16),
                        child: Padding(
                          padding: EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'By: ${answer.user} | Posted: ${dateFormatter.format(answer.createdAt)}',
                                style: TextStyle(color: Colors.grey),
                              ),
                              SizedBox(height: 8),
                              Text(answer.body),
                              SizedBox(height: 8),
                              Row(
                                children: [
                                  IconButton(
                                    icon: Icon(
                                      answer.userVote == 1
                                          ? Icons.thumb_up
                                          : Icons.thumb_up_outlined,
                                      color:
                                          answer.userVote == 1
                                              ? Colors.blue
                                              : null,
                                    ),
                                    onPressed:
                                        () => vote('answer', answer.id, 1),
                                  ),
                                  Text('${answer.voteCount}'),
                                  IconButton(
                                    icon: Icon(
                                      answer.userVote == -1
                                          ? Icons.thumb_down
                                          : Icons.thumb_down_outlined,
                                      color:
                                          answer.userVote == -1
                                              ? Colors.red
                                              : null,
                                    ),
                                    onPressed:
                                        () => vote('answer', answer.id, -1),
                                  ),
                                  Spacer(),
                                  IconButton(
                                    icon: Icon(Icons.report),
                                    onPressed: () {
                                      showDialog(
                                        context: context,
                                        builder: (context) {
                                          final reasonController =
                                              TextEditingController();
                                          return AlertDialog(
                                            title: Text('Report Answer'),
                                            content: TextField(
                                              controller: reasonController,
                                              decoration: InputDecoration(
                                                labelText: 'Reason',
                                              ),
                                            ),
                                            actions: [
                                              TextButton(
                                                onPressed:
                                                    () =>
                                                        Navigator.pop(context),
                                                child: Text('Cancel'),
                                              ),
                                              TextButton(
                                                onPressed: () {
                                                  report(
                                                    'answer',
                                                    answer.id,
                                                    reasonController.text,
                                                  );
                                                  Navigator.pop(context);
                                                },
                                                child: Text('Submit'),
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    },
                                  ),
                                  if (auth.isModeratorOrAdmin)
                                    IconButton(
                                      icon: Icon(Icons.visibility_off),
                                      onPressed:
                                          () =>
                                              hideContent('answer', answer.id),
                                    ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Post an Answer',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    TextField(
                      controller: _answerController,
                      decoration: InputDecoration(
                        labelText: 'Your Answer',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 5,
                    ),
                    SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: postAnswer,
                      style: ElevatedButton.styleFrom(
                        minimumSize: Size(double.infinity, 48),
                      ),
                      child: Text('Submit Answer'),
                    ),
                  ],
                ),
              ),
    );
  }
}
