class Answer {
  final int id;
  final String body;
  final String user;
  final DateTime createdAt;
  final DateTime updatedAt;
  int voteCount;
  int userVote;
  final bool isHidden;

  Answer({
    required this.id,
    required this.body,
    required this.user,
    required this.createdAt,
    required this.updatedAt,
    required this.voteCount,
    required this.userVote,
    required this.isHidden,
  });

  factory Answer.fromJson(Map<String, dynamic> json) {
    return Answer(
      id: json['id'],
      body: json['body'],
      user: json['user'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      voteCount: json['vote_count'],
      userVote: json['user_vote'],
      isHidden: json['is_hidden'],
    );
  }
}
