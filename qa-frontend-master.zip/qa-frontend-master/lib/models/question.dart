import 'package:qaforum/models/category.dart';
import 'package:qaforum/models/tag.dart';

class Question {
  final int id;
  final String title;
  final String body;
  final String user;
  final Category category;
  final List tags;
  final DateTime createdAt;
  final DateTime updatedAt;
  final int answerCount;
  int voteCount;
  int userVote;
  final bool isHidden;

  Question({
    required this.id,
    required this.title,
    required this.body,
    required this.user,
    required this.category,
    required this.tags,
    required this.createdAt,
    required this.updatedAt,
    required this.answerCount,
    required this.voteCount,
    required this.userVote,
    required this.isHidden,
  });

  factory Question.fromJson(Map<String, dynamic> json) {
    return Question(
      id: json['id'],
      title: json['title'],
      body: json['body'],
      user: json['user'],
      category: Category.fromJson(json['category']),
      tags: (json['tags'] as List).map((tag) => Tag.fromJson(tag)).toList(),
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      answerCount: json['answer_count'],
      voteCount: json['vote_count'],
      userVote: json['user_vote'],
      isHidden: json['is_hidden'],
    );
  }
}
