from rest_framework import serializers
from django.db.models import Sum
from .models import User, Question, Answer, Tag, Vote, Report, UserBadge, Badge, Category, QuestionTag


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name', 'description']


class UserSerializer(serializers.ModelSerializer):
    badges = serializers.SerializerMethodField()
    question_count = serializers.SerializerMethodField()
    answer_count = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'role', 'badges', 'question_count', 'answer_count', 'is_blocked']

    def get_badges(self, obj):
        return [ub.badge.name for ub in obj.userbadges.all()]

    def get_question_count(self, obj):
        return Question.objects.filter(user=obj).count()

    def get_answer_count(self, obj):
        return Answer.objects.filter(user=obj).count()


class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ['id', 'tag_name']


class QuestionSerializer(serializers.ModelSerializer):
    user = serializers.ReadOnlyField(source='user.username')
    category = CategorySerializer(read_only=True)
    tags = serializers.SerializerMethodField()
    answer_count = serializers.SerializerMethodField()
    vote_count = serializers.SerializerMethodField()
    user_vote = serializers.SerializerMethodField()

    class Meta:
        model = Question
        fields = ['id', 'title', 'body', 'user', 'category', 'tags', 'created_at', 'updated_at', 'answer_count',
                  'vote_count', 'user_vote', 'is_hidden']

    def get_tags(self, obj):
        tags = Tag.objects.filter(questiontag__question=obj)
        return TagSerializer(tags, many=True).data

    def get_answer_count(self, obj):
        return Answer.objects.filter(question=obj, is_hidden=False).count()

    def get_vote_count(self, obj):
        return Vote.objects.filter(content_type='question', content_id=obj.id).aggregate(Sum('vote'))['vote__sum'] or 0

    def get_user_vote(self, obj):
        user = self.context['request'].user
        if user.is_authenticated:
            vote = Vote.objects.filter(user=user, content_type='question', content_id=obj.id).first()
            return vote.vote if vote else 0
        return 0


class QuestionCreateSerializer(serializers.ModelSerializer):
    tags = serializers.ListField(child=serializers.CharField(), write_only=True)
    category = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all())

    class Meta:
        model = Question
        fields = ['title', 'body', 'category', 'tags']

    def validate_tags(self, value):
        for tag_name in value:
            if not Tag.objects.filter(tag_name=tag_name).exists():
                raise serializers.ValidationError(f"Tag '{tag_name}' does not exist.")
        return value

    def create(self, validated_data):
        tags_data = validated_data.pop('tags')
        validated_data.pop('user', None)  # Remove user if present to avoid duplicate
        question = Question.objects.create(user=self.context['request'].user, **validated_data)
        for tag_name in tags_data:
            tag = Tag.objects.get(tag_name=tag_name)
            QuestionTag.objects.create(question=question, tag=tag)
        return question


class AnswerSerializer(serializers.ModelSerializer):
    user = serializers.ReadOnlyField(source='user.username')
    vote_count = serializers.SerializerMethodField()
    user_vote = serializers.SerializerMethodField()

    class Meta:
        model = Answer
        fields = ['id', 'body', 'user', 'created_at', 'updated_at', 'vote_count', 'user_vote', 'is_hidden']

    def get_vote_count(self, obj):
        return Vote.objects.filter(content_type='answer', content_id=obj.id).aggregate(Sum('vote'))['vote__sum'] or 0

    def get_user_vote(self, obj):
        user = self.context['request'].user
        if user.is_authenticated:
            vote = Vote.objects.filter(user=user, content_type='answer', content_id=obj.id).first()
            return vote.vote if vote else 0
        return 0


class AnswerCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Answer
        fields = ['body']


class VoteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vote
        fields = ['content_type', 'content_id', 'vote']

    def validate(self, data):
        content_type, content_id = data['content_type'], data['content_id']
        if content_type == 'question' and not Question.objects.filter(id=content_id).exists():
            raise serializers.ValidationError("Question does not exist")
        elif content_type == 'answer' and not Answer.objects.filter(id=content_id).exists():
            raise serializers.ValidationError("Answer does not exist")
        elif content_type not in ['question', 'answer']:
            raise serializers.ValidationError("Invalid content_type")
        return data


class ReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = Report
        fields = ['reason', 'target_type', 'target_id']

    def validate(self, data):
        target_type, target_id = data['target_type'], data['target_id']
        if target_type == 'question' and not Question.objects.filter(id=target_id).exists():
            raise serializers.ValidationError("Question does not exist")
        elif target_type == 'answer' and not Answer.objects.filter(id=target_id).exists():
            raise serializers.ValidationError("Answer does not exist")
        elif target_type not in ['question', 'answer']:
            raise serializers.ValidationError("Invalid target_type")
        return data


class UserBadgeSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserBadge
        fields = ['user', 'badge', 'awarded_at']
