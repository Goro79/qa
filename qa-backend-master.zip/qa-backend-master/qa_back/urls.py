"""
URL configuration for qa_back project.
"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'questions', views.QuestionViewSet)
router.register(r'answers', views.AnswerViewSet, basename='answer')
router.register(r'tags', views.TagListView)
router.register(r'categories', views.CategoryListView)
router.register(r'reports', views.ReportCreateView, basename='report')
router.register(r'userbadges', views.UserBadgeCreateView, basename='userbadge')

urlpatterns = [
    path('api/', include(router.urls)),
    path('api/login/', views.CustomAuthToken.as_view(), name='login'),
    path('api/register/', views.RegisterView.as_view(), name='register'),
    path('api/votes/', views.VoteView.as_view(), name='vote'),
    path('api/current_user/', views.CurrentUserView.as_view(), name='current_user'),
    path('api/users/<int:user_id>/block/', views.UserBlockView.as_view(), name='user_block'),
]
