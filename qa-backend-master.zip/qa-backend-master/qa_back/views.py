from rest_framework import viewsets, permissions, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.decorators import action
from django.db.models import Count
from django.contrib.auth import login
from .models import Question, Answer, User, Tag, Vote, Category
from .serializers import (
    QuestionSerializer, QuestionCreateSerializer, AnswerSerializer, AnswerCreateSerializer,
    UserSerializer, TagSerializer, VoteSerializer, ReportSerializer, UserBadgeSerializer,
    CategorySerializer
)


class IsModeratorOrAdmin(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in ['moderator', 'administrator']


class IsAdmin(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in ['administrator']


class CustomAuthToken(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        if user.is_blocked:
            return Response({"error": "User is blocked"}, status=status.HTTP_403_FORBIDDEN)
        token, _ = Token.objects.get_or_create(user=user)
        login(request, user)  # Start session
        return Response({
            'token': token.key,
            'user_id': user.pk,
            'role': user.role,
            'username': user.username
        })


class RegisterView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username = request.data.get('username')
        email = request.data.get('email')
        password = request.data.get('password')
        if not all([username, email, password]):
            return Response({"error": "All fields are required"}, status=status.HTTP_400_BAD_REQUEST)
        if User.objects.filter(username=username).exists():
            return Response({"error": "Username already exists"}, status=status.HTTP_400_BAD_REQUEST)
        if User.objects.filter(email=email).exists():
            return Response({"error": "Email already exists"}, status=status.HTTP_400_BAD_REQUEST)
        user = User.objects.create_user(username=username, email=email, password=password, role='regular')
        token, _ = Token.objects.get_or_create(user=user)
        login(request, user)
        return Response({
            'token': token.key,
            'user_id': user.pk,
            'role': user.role,
            'username': user.username
        }, status=status.HTTP_201_CREATED)


class QuestionViewSet(viewsets.ModelViewSet):
    queryset = Question.objects.filter(is_hidden=False).select_related('user', 'category').prefetch_related(
        'question_tags__tag')
    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_class(self):
        if self.action == 'create':
            return QuestionCreateSerializer
        return QuestionSerializer

    def get_permissions(self):
        if self.action in ['update', 'destroy']:
            return [permissions.IsAuthenticated(), IsAdmin()]
        elif self.action == 'hide':
            return [permissions.IsAuthenticated(), IsModeratorOrAdmin()]
        return super().get_permissions()

    def get_queryset(self):
        queryset = super().get_queryset()
        tags = self.request.query_params.get('tags', None)
        if tags:
            tag_list = tags.split(',')
            queryset = queryset.filter(question_tags__tag__tag_name__in=tag_list).distinct()
        return queryset.order_by('-created_at')

    def perform_create(self, serializer):
        if self.request.user.is_blocked:
            raise permissions.PermissionDenied("Blocked users cannot create questions")
        serializer.save(user=self.request.user)

    @action(detail=True, methods=['post'])
    def hide(self, request, pk=None):
        question = self.get_object()
        question.is_hidden = True
        question.save()
        return Response({"status": "question hidden"})


class AnswerViewSet(viewsets.ModelViewSet):
    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_class(self):
        if self.action == 'create':
            return AnswerCreateSerializer
        return AnswerSerializer

    def get_queryset(self):
        question_id = self.request.query_params.get('question_id')
        if question_id:
            return Answer.objects.filter(question_id=question_id, is_hidden=False).select_related('user')
        return Answer.objects.filter(is_hidden=False).select_related('user')

    def get_permissions(self):
        if self.action in ['update', 'destroy']:
            return [permissions.IsAuthenticated(), IsAdmin()]
        elif self.action == 'hide':
            return [permissions.IsAuthenticated(), IsModeratorOrAdmin()]
        return super().get_permissions()

    def perform_create(self, serializer):
        if self.request.user.is_blocked:
            raise permissions.PermissionDenied("Blocked users cannot create answers")
        question_id = self.request.query_params.get('question_id')
        if not question_id or not Question.objects.filter(id=question_id).exists():
            raise serializer.ValidationError("Valid question_id is required")
        question = Question.objects.get(id=question_id)
        serializer.save(user=self.request.user, question=question)

    @action(detail=True, methods=['post'])
    def hide(self, request, pk=None):
        answer = self.get_object()
        answer.is_hidden = True
        answer.save()
        return Response({"status": "answer hidden"})


class TagListView(viewsets.ReadOnlyModelViewSet):
    queryset = Tag.objects.all()
    serializer_class = TagSerializer


class CategoryListView(viewsets.ReadOnlyModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class VoteView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        if request.user.is_blocked:
            return Response({"error": "Blocked users cannot vote"}, status=status.HTTP_403_FORBIDDEN)
        serializer = VoteSerializer(data=request.data)
        if serializer.is_valid():
            content_type = serializer.validated_data['content_type']
            content_id = serializer.validated_data['content_id']
            vote_value = serializer.validated_data['vote']
            user = request.user
            try:
                vote = Vote.objects.get(user=user, content_type=content_type, content_id=content_id)
                if vote.vote == vote_value:
                    vote.delete()
                    return Response({"status": "vote removed"})
                vote.vote = vote_value
                vote.save()
                return Response({"status": "vote updated"})
            except Vote.DoesNotExist:
                Vote.objects.create(user=user, content_type=content_type, content_id=content_id, vote=vote_value)
                return Response({"status": "vote created"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ReportCreateView(viewsets.GenericViewSet, viewsets.mixins.CreateModelMixin):
    serializer_class = ReportSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        if self.request.user.is_blocked:
            raise permissions.PermissionDenied("Blocked users cannot report")
        serializer.save(user=self.request.user)


class CurrentUserView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)


class UserBadgeCreateView(viewsets.GenericViewSet, viewsets.mixins.CreateModelMixin):
    serializer_class = UserBadgeSerializer
    permission_classes = [permissions.IsAuthenticated, IsModeratorOrAdmin]


class UserBlockView(APIView):
    permission_classes = [permissions.IsAuthenticated, IsAdmin]

    def post(self, request, user_id):
        try:
            user = User.objects.get(id=user_id)
            user.is_blocked = not user.is_blocked
            user.save()
            return Response({"status": f"User {'blocked' if user.is_blocked else 'unblocked'}"})
        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)
